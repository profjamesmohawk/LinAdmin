#if !defined(InetNtop)

/* +*+ Why isn't this in the winsock headers yet? */

#include "..\missing\inet_ntop.c"
#endif
