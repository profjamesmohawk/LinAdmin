#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>

#include <errno.h>


/*
 * Simple program to generate disk I/O
 *
 *	James Long, August 2015
 */

int nNumFiles = 0;
int nIOPS = 3;
int nFileSize = 100;

#define BS 8192


void usage(char *strName)
{
	fprintf(stderr,"\nUsage: %s -n <NumFiles>\n",strName); 
	fprintf(stderr,"\t Use <NumFiles> in /tmp\n");
	fprintf(stderr,"\t\t <NumFiles> must be between 1 and 100 \n");
	fprintf(stderr,"\t Env Var PIG_IOPS is approx IOPS\n");
	fprintf(stderr,"\t Env Var PIG_SIZE is approx size of each file in MB\n");
}

scan_args(int argc, char * argv[]){
	char *string;
	int counter;
	char *strPigIOPS;
	char *strPigSize;
	
	// we need exactly two command line args
	if ( argc != 3 ){
		usage(argv[0]);
		exit(2);
	}

	for(counter=1;counter < argc;counter++){
		string = argv[counter];


		// -n <NumFiles>
		if ( strcmp("-n",string) == 0) {
				counter++;
				if(counter >= argc) {usage(argv[0]);exit(1);} // do we have enough args?
				nNumFiles = atoi(argv[counter]);
				if(nNumFiles < 1 || nNumFiles > 100)
				{
					usage(argv[0]);
					exit(1);
				}
				continue;
		}
	}

	// process env args
	//

	nIOPS=10;
	strPigIOPS = getenv("PIG_IOPS");
        if(strPigIOPS){
                nIOPS = atoi(strPigIOPS);
                if (nIOPS < 1 ) nIOPS = 10;
                if (nIOPS > 100 ) nIOPS = 100;
        }
		
	nFileSize=100;
	strPigSize = getenv("PIG_SIZE");
        if(strPigSize){
                nFileSize = atoi(strPigSize);
                if (nFileSize < 1 ) nFileSize = 10;
                if (nIOPS > 1000 ) nFileSize = 1000;
		nFileSize = (int)(((float) nFileSize * (float)1000000)/(float)BS);
        }
}


main(int argc, char *argv[])
{
	char Data[BS];
	char strFileName[1024];
	int i;
	int j;
	int aFiles[100];
	int nWritesPerSecond;
	int nPigRate;
	char* strPigRate;
	int blnWriteError=0;
	int nBytesWritten;
	int nTotalBytesWritten=0;
	int foo;

	scan_args(argc, argv);

	// initialze the data
	memset(Data,'j',BS);

	// open and init the files
	//
	for(i=0;i<nNumFiles; i++){
		sprintf(strFileName,"/tmp/pig_%d",i+1000);
		//aFiles[i] = open(strFileName,O_CREAT|O_SYNC|O_TRUNC|O_RDWR);
		aFiles[i] = open(strFileName,O_CREAT|O_TRUNC|O_RDWR);
		if(aFiles[i] == -1){
			fprintf(stderr,"Error opening %s, %s\n",strFileName, strerror(errno));
			exit(1);
		}
		if( fchmod(aFiles[i],00666)){
			fprintf(stderr,"Error changing permissions.\n");
			exit(1);
		}

		for(j=0;j<nFileSize;j++){
			nBytesWritten = write(aFiles[i],Data,BS);		
			if(nBytesWritten == -1){
				fprintf(stderr,"Write Error %d:%s, %s\n",aFiles[i],strFileName, strerror(errno));
				exit(1);
			}
		}
	}

	// do some random reads and writes
	//
	while(1){
		for(i=0;i<nNumFiles;i++){
			for(j=0;j<nIOPS;j++){

				// seek to a random spot in the file
						//(rand()*nFileSize)/RAND_MAX * BS,
				(void) lseek (	aFiles[i],
		 				(int)(((float)rand()*(float)nFileSize)/(float)RAND_MAX) * BS,
						SEEK_SET);
				// do a read
				read( aFiles[i],Data,BS);

				// seek to a random spot in the file
				(void) lseek (	aFiles[i],
		 				(int)(((float)rand()*(float)nFileSize)/(float)RAND_MAX) * BS,
						SEEK_SET);
				// do a write
				write( aFiles[i],Data,BS);

			}
		}
		sleep(1);
	}

}
