gcc -o memHog m.c
gcc -o cpuHog c.c
gcc -o diskHog d.c
gcc -o ioHog i.c

mkdir pigs

cp memHog pigs/ham
cp cpuHog pigs/bacon
cp diskHog pigs/lard
cp ioHog pigs/chorizo

cp ReadMe pigs
cp pi.sh pigs
cp run_pigs.sh pigs

mv memHog pigs
mv cpuHog pigs
mv diskHog pigs
mv ioHog pigs

tar cf pigs.tar ./pigs
zip pigs.zip pigs.tar
