#!/bin/bash

echo "Launching programs to generate load..."

export PIG_SIZE=200

rm /tmp/pig_*

./bacon -n 200 &

./ham -n 400 &

./chorizo -n 2 &

./lard -n 1 &
