#!/bin/bash

#
# A trivial perl script to create an HTML page containing the current date and time
# Spits an html page to stdout
#
# James Long
# Spring, 2021

echo   '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">' 
echo   '<html>' 
echo   '<head>' 
echo   '<meta content="text/html" charset="ISO-8859-1" http-equiv="content-type">'
echo   ' <title> Trival Web Page - Date </title>' 
echo   '</head>' 
echo   '<body>' 
echo   "<h2>" 
date 
echo   '</h2>'
echo   '</body>' 
echo   '</html>' 

